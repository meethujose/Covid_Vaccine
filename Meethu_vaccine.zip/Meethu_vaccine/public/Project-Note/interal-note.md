git fetch origin master
git merge origin/master
<!-- merge to master -->
